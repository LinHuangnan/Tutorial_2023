# week2 tasks

* Service与Client通信 已完成
* 小车模型urdf构建 已完成
* 编写launch文件来启动节点 已完成
* 编写小车行进程序
  * 完成行进方向为车头朝向的功能
  * 通过 Publisher控制小车运动 未完成 
    * 小车框架大致搭好，但是消息msg问题没处理

* 小车走s型 未完成