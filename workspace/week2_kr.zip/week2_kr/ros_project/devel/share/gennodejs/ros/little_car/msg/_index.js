
"use strict";

let Car = require('./Car.js');

module.exports = {
  Car: Car,
};
