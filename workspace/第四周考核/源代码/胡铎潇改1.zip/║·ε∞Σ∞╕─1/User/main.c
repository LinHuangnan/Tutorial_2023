#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include <stdio.h>
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "AD.h"
#include "Serial.h"

uint8_t KeyNum;
float Angle1;
float *a=&Angle1;
float Angle2;
float *b=&Angle2;
float Angle3;
float *c=&Angle3;
float Angle4;
float *d=&Angle4;
float Angle01;
float Angle02;
float Angle03;
float Angle04;
int blu=0;
int key=0;
int main(void)
{
	OLED_Init();
	Servo_Init();
	Key_Init();
	AD_Init();
	Serial_Init();
	
	OLED_ShowString(1, 1, "A1:");
	OLED_ShowString(2, 1, "A2:");
	OLED_ShowString(1, 8, "A3:");
	OLED_ShowString(2, 8, "A4:");
	while (1)
	{

//memory
		OLED_ShowNum(3, 1,key, 3);
		if(Key_GetNum()==1 && key==0)
		{
			
			key=key+1;
			OLED_ShowNum(3, 1,key, 3);
			if( key==1)
			{
				Angle01=Angle1;
				Angle02=Angle2;
				Angle03=Angle3;
				Angle04=Angle4; 
			}
		}
		while(key==1)
		{
			//detect key and exit

		  //
	 
		OLED_ShowNum(1, 4, Angle1, 3);
		OLED_ShowNum(2, 4, Angle2, 3);
    OLED_ShowNum(1, 11, Angle3, 3);
		OLED_ShowNum(2, 11, Angle4, 3);
		
	 Angle1=AD_GetAngel(ADC_Channel_4) ;

	 Angle2=AD_GetAngel(ADC_Channel_5) ;

   Angle3=AD_GetAngel(ADC_Channel_6) ;

	 Angle4=AD_GetAngel(ADC_Channel_7) ;
		
		Servo_SetAngle1(Angle1);
	  Servo_SetAngle2(Angle2);
    Servo_SetAngle3(Angle3);
	  Servo_SetAngle4(Angle4);
		
					if(Key_GetNum()==1)
		{
			
		Servo_SetAngle1(Angle01);
	  Servo_SetAngle2(Angle02);
    Servo_SetAngle3(Angle03);
	  Servo_SetAngle4(Angle04);
			  key=2;
			OLED_ShowNum(3, 1,key, 3);
			break;
			
			
		}
	}
	
		while(key==2)
		{
			
			Delay_ms(2000);
			while(Angle1<Angle01)
			{
				Angle01--;
				Delay_ms(10);
			Servo_SetAngle1(Angle01);
			}
		while(Angle1>Angle01)
			{
				Angle01++;
				Delay_ms(20);
			Servo_SetAngle1(Angle01);
			}
				Delay_ms(1000);
			while(Angle2<Angle02)
			{
				Angle02--;
				Delay_ms(20);
			Servo_SetAngle2(Angle02);
			}
		while(Angle2>Angle02)
			{
				Angle02++;
				Delay_ms(20);
			Servo_SetAngle2(Angle02);
			}
	  
		Delay_ms(1000);
 while(Angle3<Angle03)
			{
				Angle03--;
				Delay_ms(20);
			Servo_SetAngle3(Angle03);
			}
		while(Angle3>Angle03)
			{
				Angle03++;
				Delay_ms(20);
			Servo_SetAngle3(Angle03);
			}
		Delay_ms(1000);
			while(Angle4<Angle04)
			{
				Angle04--;
				Delay_ms(20);
			Servo_SetAngle4(Angle04);
			}
		while(Angle4>Angle04)
			{
				Angle04++;
				Delay_ms(20);
			Servo_SetAngle4(Angle04);
			}
	  
			key=0;
			break;
		
		
		}
		
		
//		bluetooth
		if (blueon()==1)
  {
	   blu =1;
	}
	
if (Serial_GetRxFlag() == 1)
		{
		OLED_ShowHexNum(4, 4, Serial_RxPacket[0], 2);
    OLED_ShowHexNum(4, 8, Serial_RxPacket[1], 2);
		}
		
		while (blu==1)
{
	
	if (blueoff()==1)
  {
	blu =0;
	 }
	
	 	 OLED_ShowNum(1, 4,*a, 3);
		OLED_ShowNum(2, 4,*b, 3);
    OLED_ShowNum(1, 11,*c, 3);
		OLED_ShowNum(2, 11,*d, 3);
	judge(a,b,c,d);
	 	OLED_ShowNum(1, 4,*a, 3);
		OLED_ShowNum(2, 4,*b, 3);
    OLED_ShowNum(1, 11,*c, 3);
		OLED_ShowNum(2, 11,*d, 3);
	 Servo_SetAngle1(Angle1);
	 Servo_SetAngle2(Angle2);
   Servo_SetAngle3(Angle3);
	 Servo_SetAngle4(Angle4);
  
}

	
//
   Angle1=AD_GetAngel(ADC_Channel_4) ;

	 Angle2=AD_GetAngel(ADC_Channel_5) ;

   Angle3=AD_GetAngel(ADC_Channel_6) ;

	 Angle4=AD_GetAngel(ADC_Channel_7) ;

	 Servo_SetAngle1(Angle1);
	 Servo_SetAngle2(Angle2);
   Servo_SetAngle3(Angle3);
	 Servo_SetAngle4(Angle4);
		OLED_ShowNum(1, 4, Angle1, 3);
		OLED_ShowNum(2, 4, Angle2, 3);
    OLED_ShowNum(1, 11, Angle3, 3);
		OLED_ShowNum(2, 11, Angle4, 3);
	}
}
