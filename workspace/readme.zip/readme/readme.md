# 任务一
## makefile
makefile描述了工程的编译和连接规则。
好处：在修改文件后，便于重
     &emsp; 新编译，提高效率
#### 步骤
1.先创建源文件，在终端中用
&emsp; touch创建，用ls命令看
&emsp;是否创建成功
2.在终端中gcc命令编译可执文
&emsp;件，c++文件后要加上-lstdc++
&emsp;用ls查看是否生成可执行文件
3.touch创建makefile文件， 
&emsp;gedit编译，注意Tab缩进
![1](.\ros\1.png)
#### 一些符号的意思
    ./ 目前所在目录
    ../ 代表上一层目录
    / 根目录
## Cmake
定义：跨平台编译工具
功能：配置和生成各大平台工程
&emsp;生成makefiles文件
#### 一些函数的意思
	add_executable( ):第一个参数是映射名，后面的参数是使用的源文件
	project():显示本工程的信息，参数为自定义工程名
    add_source_directory(dir var)：dir是指定目录，var是自定义存放源文件的列表，用于将指定目录的所有文件放在列表中
    set() 参数1是列表名，后面的参数是自定义要加入其中的目录文件
    include_directories()用于向工程添加多个指定头文件搜索路径的，路径与路径间用空格隔开
#### 步骤
1.创建文件夹cmake，在其在创建include文件夹放置头文件，创建src源文件放置源文件
2.在cmake根目录下创建cmakelists文本
![2](.\ros\2.png)
3.在src下也创建cmakelists文本
![3](.\ros\3.png)
4.终端中执行cmake和make命令
## 任务实现
1.include下头文件
2.src源文件
3cmakelists编写，和上图一致
4执行命令
![4](.\ros\4.png)

# 任务二
shell文本后缀为.sh
shell脚本第一行为（表示使用bash）
    
    
    #！/bin/bash
## 任务2.1
1.创建目录

    mkdir -p 目录名：递归创建目录
    ls -ld 目录名：查看目录是否创建
    chmod +x ./文档名.sh 打开权限创建目录
2.切换工作目录

    cd dir 切换到当前目录
    cd /切换到根目录
    cd ..切换到上级目录
遇到的奇怪问题：进了子目录，不能再开上一级文件权限，不然会报错，原因没有权限
3.复制目录

    cp -r 复制的目录绝对地址 重命名的名字
可在终端中用tree查看
4改变属主
&emsp;（1）创建新的用户，在终端中

    sudo useradd 新用户名，一定sudo，超级管理员权限
    sudo passwd 新用户名：给新用户设置密码
&emsp;（2）更改目录属主

    sudo chown -R 新属主名 要更改的对象
    遇到问题：权限不够，命令前加sudo
5.修改其他用户权限

    ll ：终端中命令，查看目录，可查看属主和权限
    chmod 770 要更改对象 ：修改其他用户对其权限为所有都没有
![5](.\ros\5.png)
![6](.\ros\6.png)
![7](.\ros\7.png)
![8](.\ros\8.png)
6.总
![9](.\ros\9.png)
![10](.\ros\10.png)

##任务2.2
    date:显示时间
    mkdir -p：创建目录
    touch 文件/目录名：创建文件
    find -name 特征* 查找文件
注意要先在终端打开权限
![11](.\ros\11.png)
![12](.\ros\12.png)
![13](.\ros\13.png)
![14](.\ros\14.png)
## 任务2.3
![15](.\ros\15.png)
![16](.\ros\16.png)
![17](.\ros\17.png)
![18](.\ros\18.png)
注意if和case格式
![19](.\ros\19.png)

#任务三
## 1.基本知识
![20](.\ros\20.png)
## 2.步骤及其详解
### （1）在终端创建工作空间和子集，在子集中创建包my_topioc

    mkdir -p xxx_ws/src
    catkin_create_pkg 包名 roscpp std_msgs geometry_msgs rospy 后面是依赖包 
    roscpp:c++程序的接口
    std_msgs:封装原生数据类型
&emsp;创建完后如下
&emsp;![21](.\ros\21.png)
&emsp;![22](.\ros\22.png)
### （2）自定义消息类型创建
&emsp;&emsp;创建位置：my_topic的文夹中新建个msg文件夹
&emsp;&emsp;创建文件后缀：.msg
&emsp;&emsp;创建内容：
&emsp;&emsp;&emsp;![23](.\ros\23.png)
### （3）编写发布者源文件
    相关函数和类型
    ros::init(argc,argv,"名字")；初始化节点，相当于初始化个情报中心
    ros::NodeHandle nh;初始化节点句柄。nh相当于情报中心的门，通过这个进入其，对其做出操作
    ros::advertise<>( 1,2 ): <>内是数据泛型，第一个参数是话题名，int是缓冲区大小
    ros::Rate loop_rate(频率);发布频率
    发布对象名.publish(消息变量)；发布消息
    ROS_INFO()输出函数
    loop_rate.sleep()和发布频率搭配使用
### (4)编写订阅者源文件
    相关操作及其解释
    句柄名.subscribe(订阅话题名，缓冲区大小，回调函数)；接受到消息后回调函数
    ros::spin();循环等待回调函数
### (5)配置文件修改
     [1].find_package修改：目的链接库
     [2].add_message_files修改，导入自定义类型
     [3].generate_messages()修改
     [4].catkin_package修改
     [5].add_excutable和targetlink修改


    修改package.xml
### (6)运行结果
&emsp;![24](.\ros\24.png)
&emsp;![25](.\ros\25.png)
