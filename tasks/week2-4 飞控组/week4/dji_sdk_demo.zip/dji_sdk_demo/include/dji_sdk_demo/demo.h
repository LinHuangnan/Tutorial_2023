/** @file demo_flight_control.h
 *  @version 3.3
 *  @date May, 2017
 *
 *  @brief
 *  demo sample of how to use flight control APIs
 *
 *  @copyright 2017 DJI. All rights reserved.
 *
 */

#ifndef DEMO_FLIGHT_CONTROL_H
#define DEMO_FLIGHT_CONTROL_H

// ROS includes
#include <ros/ros.h>
#include <geometry_msgs/QuaternionStamped.h>
#include <geometry_msgs/Vector3Stamped.h>
#include <sensor_msgs/NavSatFix.h>
#include <std_msgs/UInt8.h>

// DJI SDK includes
#include <dji_sdk/DroneTaskControl.h>
#include <dji_sdk/SDKControlAuthority.h>
#include <dji_sdk/QueryDroneVersion.h>
#include <dji_sdk/SetLocalPosRef.h>


#include <tf/tf.h>
#include <sensor_msgs/Joy.h>

#define C_EARTH (double)6378137.0
#define C_PI (double)3.141592653589793
#define DEG2RAD(DEG) ((DEG) * ((C_PI) / (180.0)))

/*!
 * @brief a bare bone state machine to track the stage of the mission
 */
class Mission {
public:
  Mission() {}
  ~Mission() {}

  void reset() {
    state = 0;
  }

  void setTarget(float x, float y, float z, float speed) {
    target_local_position.x = x;
    target_local_position.y = y;
    target_local_position.z = z;
    target_speed = speed;
  }

  void step(sensor_msgs::NavSatFix current_gps, geometry_msgs::Point current_local_pos, geometry_msgs::Quaternion current_atti) {
    if (state == 0) {
      // Take off to a height of 10m
      if (current_local_pos.z - start_local_position.z > 9.0) {
        state = 1;
        ROS_INFO("Takeoff complete. Starting circle mission.");
      }
    } else if (state == 1) {
      // Fly to the first target point
      float dx = target_local_position.x - current_local_pos.x;
      float dy = target_local_position.y - current_local_pos.y;
      float dz = target_local_position.z - current_local_pos.z;
      float distance = sqrt(dx*dx + dy*dy + dz*dz);

      if (distance < target_radius) {
        state = 2;
        ROS_INFO("Reached first target point.");
      } else {
        float yaw = atan2(dy, dx);
        ctrlPosYawPub.publish(getFlightControlMessage(current_local_pos.x, current_local_pos.y, current_local_pos.z, yaw, target_speed, 0));
      }
    } else if (state == 2) {
      // Fly to the second target point
      float dx = start_local_position.x - current_local_pos.x;
      float dy = start_local_position.y - current_local_pos.y;
      float dz = start_local_position.z - current_local_pos.z;
      float distance = sqrt(dx*dx + dy*dy + dz*dz);

      if (distance < target_radius) {
        state = 3;
        ROS_INFO("Reached second target point.");
      } else {
        float yaw = atan2(dy, dx);
        ctrlPosYawPub.publish(getFlightControlMessage(current_local_pos.x, current_local_pos.y, current_local_pos.z, yaw, target_speed, 0));
      }
    } else if (state == 3) {
      // Land
      if (current_local_pos.z - start_local_position.z < 0.2) {
        drone_task_service.request.task = 4; // Landing
        drone_task_service.call(request, response);
      }
    }
  }

  int state = 0;
  geometry_msgs::Point start_local_position;
  geometry_msgs::Point target_local_position;
  float target_speed;
  const float target_radius = 0.5;
  int outbound_counter = 0;
  int inbound_counter = 0; 
  int break_counter = 0; 

};


void localOffsetFromGpsOffset(geometry_msgs::Vector3&  deltaNed,
                         sensor_msgs::NavSatFix& target,
                         sensor_msgs::NavSatFix& origin);

geometry_msgs::Vector3 toEulerAngle(geometry_msgs::Quaternion quat);

void display_mode_callback(const std_msgs::UInt8::ConstPtr& msg);

void flight_status_callback(const std_msgs::UInt8::ConstPtr& msg);

void gps_callback(const sensor_msgs::NavSatFix::ConstPtr& msg);

void attitude_callback(const geometry_msgs::QuaternionStamped::ConstPtr& msg);

void local_position_callback(const geometry_msgs::PointStamped::ConstPtr& msg);

bool takeoff_land(int task);

bool obtain_control();

bool is_M100();

bool monitoredTakeoff();

bool M100monitoredTakeoff();

bool set_local_position();

#endif // DEMO_FLIGHT_CONTROL_H
