#include<iostream>
#include<string>
#include<opencv2/opencv.hpp>
#include"Recovery.h"
//#include<chrono>
//using namespace std::chrono;
using namespace cv;
using namespace std;
void Recovery::readCannel(int n) //电脑自带摄像头流默认为“0”
{
    cap = VideoCapture(n); //读取视频流
    if(!cap.isOpened()) //判断摄像头是否打开成功
    {
        cout << "Error" << endl;
        return;
    }


}


void Recovery::readVideo(String filePath) //通过绝对路径来打开视频
{
    cap.open(filePath);  //通过绝对路径来打开视频
    if(!cap.isOpened()) //判断读取视频是否成功
    {
	cout << "Error" << endl;
    	return;
    }
	
}

void Recovery::process()
{
    while(true)
    {
		Mat frame;
		bool ret = cap.read(frame); //判断读取视频帧
	if(!ret)
	{
	    break;
	}
	Mat gray;
	Mat fgmask;
	cvtColor(frame, gray, COLOR_BGR2GRAY); //将图片转化为灰度图
	
	absdiff(gray, mean(gray),fgmask); //计算当前帧图像的灰度图与平均灰度图像之间的差异
	
	imshow("frame", frame);
	imshow("mask", fgmask);
	
	if(waitKey(30)==27)
	{
	    break;
	}

	imwrite("video1.jpg",frame);	//保存图片
    }
    
    cap.release();		
    destroyAllWindows();	//关闭所有窗口，释放缓存区
}

void Recovery::showResult()
{
    img = imread("video1.jpg");  //将之前保存下来的图片展示出来
    imshow("result",img);
    waitKey(0);
}

