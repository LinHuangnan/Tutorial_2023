#include<iostream>
#include<string>
#include<opencv2/opencv.hpp>
//#include<chrono>
//using namespace std::chrono;
using namespace cv;
using namespace std;

class Recovery {

public:
    /* readVideo
    * @param filePath 文件绝对路径
    * 根据绝对路径读取需要还原背景的文件
    */
    void readVideo(String filePath);

    /* process
    * 进行还原过程
    */
    void process();

    /* showResult
    * 窗口展示背景还原后的结果
    */
    void showResult();

    void readCannel(int n);

private:
    Mat img;
    VideoCapture cap;
};

