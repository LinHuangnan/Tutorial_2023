#include<iostream>
#include<string>
#include<opencv2/opencv.hpp>
#include"Recovery.h"
#include<chrono>
//using namespace std::chrono;
using namespace cv;
using namespace std::chrono;

int main()
{
    auto start = high_resolution_clock::now();
    Recovery r;
    r.readVideo("/home/jerry/code/task/video1.mp4");
    r.process();
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
    r.showResult();
    cout << "time：" << duration.count() << " ms" << endl;
    return 0;
}
